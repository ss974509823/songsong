
from .forms import LoginForm


def login_model_form(requests):
    return {'login_model_form': LoginForm()}
