
from django.urls import path
from . import views

urlpatterns = [
    path('update_comment', views.UpdateCommit.as_view(), name='update_comment')
]
