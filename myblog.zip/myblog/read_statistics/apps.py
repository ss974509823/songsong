from django.apps import AppConfig


class ReadStatisticsConfig(AppConfig):
    name = 'read_statistics'
