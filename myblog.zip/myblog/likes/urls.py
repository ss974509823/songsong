

from django.urls import path
from . import views

urlpatterns = [
    path('like_change', views.LikeChange.as_view(), name='like_change'),
]
